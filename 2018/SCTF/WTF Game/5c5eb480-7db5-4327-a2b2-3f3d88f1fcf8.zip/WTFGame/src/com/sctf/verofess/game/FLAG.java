package com.sctf.verofess.game;

public class FLAG {
    @Override
    public String toString(){
        return "TEST_FLAG";
    }
}
